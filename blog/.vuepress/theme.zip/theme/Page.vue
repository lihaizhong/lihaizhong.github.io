<template>
  <PageLayout></PageLayout>
</template>

<script>
export default {
  created() {}
};
</script>

